
import React, { useState, useEffect, useRef } from 'react';
import { clinicalApi } from './services/api';
import { Message, HealthStatus, DecayMethod } from './types';
import { MessageBubble } from './components/MessageBubble';
import { RiskPredictor } from './components/RiskPredictor';
import { MedicalSearch } from './components/MedicalSearch';
import { VoiceMode } from './components/VoiceMode';
import { HeartIcon, SendIcon, HistoryIcon, SearchIcon, AlertIcon, LibraryIcon } from './components/Icons';

type AppView = 'chat' | 'predictor' | 'research';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('chat');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [method, setMethod] = useState<DecayMethod>('etvd');
  const [isLoading, setIsLoading] = useState(false);
  const [health, setHealth] = useState<HealthStatus>({ status: 'checking' });
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (view === 'chat') scrollToBottom();
  }, [messages, isLoading, view]);

  useEffect(() => {
    const checkApi = async () => {
      const status = await clinicalApi.checkHealth();
      setHealth(status);
    };
    checkApi();
  }, []);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsLoading(true);

    try {
      const response = await clinicalApi.query(currentInput, method);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.answer,
        sources: response.sources,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error: any) {
      const errM: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `Error: ${error.message || 'API Unavailable'}`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errM]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans">
      {isVoiceActive && <VoiceMode onClose={() => setIsVoiceActive(false)} />}
      
      <aside className={`${sidebarOpen ? 'w-80' : 'w-0'} bg-slate-900 text-white flex flex-col transition-all duration-300 ease-in-out overflow-hidden`}>
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="bg-teal-500 p-2 rounded-lg">
            <HeartIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight">Clinical RAG</h1>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Diagnostics Hub</p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-6 px-4 space-y-2">
          <div className="px-3 mb-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Clinical Workbench</div>
          <button onClick={() => setView('chat')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${view === 'chat' ? 'bg-teal-600/10 text-teal-400 border border-teal-600/20' : 'text-slate-400 hover:bg-slate-800'}`}>
            <SearchIcon className="w-5 h-5" />
            Evidence Chat
          </button>
          <button onClick={() => setView('predictor')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${view === 'predictor' ? 'bg-teal-600/10 text-teal-400 border border-teal-600/20' : 'text-slate-400 hover:bg-slate-800'}`}>
            <AlertIcon className="w-5 h-5" />
            Risk Forecaster
          </button>
          <button onClick={() => setView('research')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${view === 'research' ? 'bg-teal-600/10 text-teal-400 border border-teal-600/20' : 'text-slate-400 hover:bg-slate-800'}`}>
            <LibraryIcon className="w-5 h-5" />
            Research Pulse
          </button>
          
          <div className="pt-8 px-3 mb-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Voice Interaction</div>
          <button onClick={() => setIsVoiceActive(true)} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-emerald-400 hover:bg-emerald-500/10 transition-colors text-sm font-bold border border-emerald-500/20">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
             Live Consult Mode
          </button>
        </nav>

        <div className="p-4 bg-slate-950 border-t border-slate-800">
           <div className="flex items-center justify-between text-[10px] text-slate-500 uppercase font-bold tracking-widest">
              <span>Status: {health.status}</span>
              <span className={`w-2 h-2 rounded-full ${health.status === 'ok' ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
           </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 z-10">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1.5 hover:bg-slate-100 rounded-md text-slate-500 transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" /></svg>
            </button>
            <h2 className="font-semibold text-slate-700">
              {view === 'chat' ? 'Evidence-Based Consultation' : view === 'predictor' ? 'Predictive Analytics' : 'Medical Research Pulse'}
            </h2>
          </div>
          
          {view === 'chat' && (
            <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg">
              <span className="text-[10px] font-bold text-slate-500 px-2 uppercase">Retrievable Decay</span>
              <select value={method} onChange={(e) => setMethod(e.target.value as DecayMethod)} className="bg-white border border-slate-200 text-xs rounded-md px-2 py-1 outline-none font-medium">
                <option value="etvd">ETVD</option>
                <option value="sigmoid">Sigmoid</option>
                <option value="bioscore">Bioscore</option>
              </select>
            </div>
          )}
        </header>

        <div className="flex-1 overflow-y-auto px-6 py-8 md:px-12 bg-slate-50/50">
          {view === 'predictor' ? <RiskPredictor /> : view === 'research' ? <MedicalSearch /> : (
            <div className="max-w-5xl mx-auto w-full flex flex-col h-full">
              {messages.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                  <div className="w-16 h-16 bg-teal-50 rounded-2xl flex items-center justify-center text-teal-600"><HeartIcon className="w-10 h-10" /></div>
                  <h3 className="text-2xl font-bold text-slate-800">Evidence-Based Clinical Chat</h3>
                  <p className="text-slate-500 max-w-lg">Grounded in PubMed, providing synthesized clinical data for cardiology and heart failure cases.</p>
                </div>
              ) : messages.map((msg) => <MessageBubble key={msg.id} message={msg} />)}
              {isLoading && <div className="animate-pulse flex items-center gap-2 mb-8"><div className="w-8 h-8 rounded-full bg-teal-100"></div><div className="h-12 bg-white rounded-xl w-[60%]"></div></div>}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {view === 'chat' && (
          <div className="p-6 bg-white border-t border-slate-100">
            <form onSubmit={handleSubmit} className="max-w-4xl mx-auto flex gap-3">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSubmit())}
                placeholder="Consult the clinical knowledge base..."
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-6 py-3 outline-none focus:ring-2 focus:ring-teal-500 resize-none h-14"
              />
              <button disabled={isLoading || !input.trim()} className="bg-teal-600 text-white p-3 rounded-xl hover:bg-teal-700 transition-all shadow-md active:scale-95 disabled:bg-slate-300">
                <SendIcon />
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
