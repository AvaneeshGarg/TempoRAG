
export type DecayMethod = 'etvd' | 'sigmoid' | 'bioscore';

export interface Source {
  year: string;
  title: string;
  score: number;
}

export interface QueryResponse {
  answer: string;
  sources: Source[];
}

export interface PredictionResponse {
  risk_1d: number;
  risk_7d: number;
  risk_30d: number;
  confidence_score?: number;
  patient_id?: string;
  recommendations?: string[];
}

export interface ResearchItem {
  title: string;
  snippet: string;
  url: string;
  publishedDate?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: Source[];
  timestamp: Date;
}

export interface HealthStatus {
  status: 'ok' | 'error' | 'checking';
}

export interface PatientVitals {
  age: number;
  bnp: number;
  lvef: number;
  systolicBP: number;
  diastolicBP: number;
  heartRate: number;
}
