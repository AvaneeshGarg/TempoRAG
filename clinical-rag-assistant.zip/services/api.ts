
import { HealthStatus, QueryResponse, DecayMethod, PredictionResponse } from '../types';

const BASE_URL = 'http://localhost:8000';

export const clinicalApi = {
  async checkHealth(): Promise<HealthStatus> {
    try {
      const response = await fetch(`${BASE_URL}/health`);
      if (!response.ok) throw new Error('Health check failed');
      const data = await response.json();
      return { status: data.status === 'ok' ? 'ok' : 'error' };
    } catch (error) {
      console.error('API Health Check Error:', error);
      return { status: 'error' };
    }
  },

  async query(question: string, method: DecayMethod): Promise<QueryResponse> {
    const response = await fetch(`${BASE_URL}/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ question, method }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Failed to fetch response from clinical assistant');
    }

    return response.json();
  },

  async predict(file: File): Promise<PredictionResponse> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch(`${BASE_URL}/predict`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Prediction request failed. Ensure the file format is supported.');
    }

    return response.json();
  }
};
