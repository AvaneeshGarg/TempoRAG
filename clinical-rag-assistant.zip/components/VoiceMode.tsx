
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { HeartIcon } from './Icons';

export const VoiceMode: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [status, setStatus] = useState('Initializing voice session...');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);

  const startSession = async () => {
    setStatus('Connecting to Gemini Live...');
    setIsActive(true);
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Manual Implementation of encoding/decoding as per requirements
    const encode = (bytes: Uint8Array) => {
      let binary = '';
      const len = bytes.byteLength;
      for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
      return btoa(binary);
    };

    const decode = (base64: string) => {
      const binaryString = atob(base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
      return bytes;
    };

    const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
      const dataInt16 = new Int16Array(data.buffer);
      const frameCount = dataInt16.length / numChannels;
      const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
      for (let channel = 0; channel < numChannels; channel++) {
        const channelData = buffer.getChannelData(channel);
        for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
      return buffer;
    };

    let nextStartTime = 0;
    const outCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const inCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    audioContextRef.current = outCtx;

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    const sessionPromise = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks: {
        onopen: () => {
          setStatus('Listening...');
          const source = inCtx.createMediaStreamSource(stream);
          const processor = inCtx.createScriptProcessor(4096, 1, 1);
          processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const int16 = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
            sessionPromise.then(s => s.sendRealtimeInput({ 
              media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } 
            }));
          };
          source.connect(processor);
          processor.connect(inCtx.destination);
        },
        onmessage: async (msg) => {
          if (msg.serverContent?.outputTranscription) {
            setTranscription(prev => prev + ' ' + msg.serverContent!.outputTranscription!.text);
          }
          const audio = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (audio) {
            nextStartTime = Math.max(nextStartTime, outCtx.currentTime);
            const buf = await decodeAudioData(decode(audio), outCtx, 24000, 1);
            const src = outCtx.createBufferSource();
            src.buffer = buf;
            src.connect(outCtx.destination);
            src.start(nextStartTime);
            nextStartTime += buf.duration;
          }
        },
        onclose: () => setIsActive(false),
        onerror: (e) => console.error(e)
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } } },
        systemInstruction: "You are a senior clinical consultant. Provide concise, evidence-based audio responses.",
        // Fix: Enable transcription of model output as handled in onmessage
        outputAudioTranscription: {},
      }
    });
    sessionRef.current = await sessionPromise;
  };

  useEffect(() => {
    startSession();
    return () => {
      sessionRef.current?.close();
      audioContextRef.current?.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
      <div className="bg-white w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        <div className="p-8 flex flex-col items-center text-center">
          <div className="w-20 h-20 bg-teal-500 rounded-full flex items-center justify-center mb-6 animate-pulse shadow-lg shadow-teal-500/30">
            <HeartIcon className="w-10 h-10 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-slate-800 mb-1">Live Clinical Assistant</h3>
          <p className="text-teal-600 font-bold text-xs uppercase tracking-widest">{status}</p>
          
          <div className="mt-8 w-full bg-slate-50 rounded-2xl p-6 min-h-[120px] max-h-[200px] overflow-y-auto text-left border border-slate-100">
             <p className="text-sm text-slate-600 leading-relaxed italic">
                {transcription || "Transcribing consultation in real-time..."}
             </p>
          </div>
        </div>
        
        <div className="bg-slate-50 p-6 flex items-center justify-between border-t border-slate-100">
           <div className="flex items-center gap-2">
              <div className="flex gap-1">
                 {[1,2,3,4,5].map(i => (
                   <div key={i} className={`w-1 h-6 bg-teal-500 rounded-full animate-bounce`} style={{ animationDelay: `${i * 0.1}s` }}></div>
                 ))}
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Audio Stream Active</span>
           </div>
           <button 
             onClick={onClose}
             className="bg-slate-900 text-white px-8 py-2.5 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-md"
           >
             End Consultation
           </button>
        </div>
      </div>
    </div>
  );
};
