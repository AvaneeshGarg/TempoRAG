
import React from 'react';
import { Message } from '../types';
import { SourceCard } from './SourceCard';
import { HeartIcon } from './Icons';

interface MessageBubbleProps {
  message: Message;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isAssistant = message.role === 'assistant';

  return (
    <div className={`flex flex-col mb-8 ${isAssistant ? 'items-start' : 'items-end'}`}>
      <div className="max-w-[85%] lg:max-w-[70%]">
        <div className={`flex items-center gap-2 mb-2 ${isAssistant ? 'flex-row' : 'flex-row-reverse'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-sm ${
            isAssistant ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-600'
          }`}>
            {isAssistant ? <HeartIcon className="w-5 h-5" /> : <span className="text-xs font-bold">MD</span>}
          </div>
          <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
            {isAssistant ? 'Clinical Assistant' : 'Physician'}
          </span>
          <span className="text-[10px] text-slate-400">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>

        <div className={`px-5 py-4 rounded-2xl shadow-sm leading-relaxed ${
          isAssistant 
            ? 'bg-white border border-slate-200 text-slate-800 rounded-tl-none' 
            : 'bg-teal-700 text-white rounded-tr-none'
        }`}>
          <div className="markdown-content whitespace-pre-wrap text-sm md:text-base">
            {message.content}
          </div>
        </div>

        {isAssistant && message.sources && message.sources.length > 0 && (
          <div className="mt-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
              <span className="h-[1px] bg-slate-200 flex-1"></span>
              Clinical Sources
              <span className="h-[1px] bg-slate-200 flex-1"></span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {message.sources.map((source, idx) => (
                <SourceCard key={idx} source={source} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
