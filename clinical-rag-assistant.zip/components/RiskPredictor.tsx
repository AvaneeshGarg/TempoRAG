
import React, { useState } from 'react';
import { clinicalApi } from '../services/api';
import { PredictionResponse, PatientVitals } from '../types';
// Fix: Import LibraryIcon to solve the reference error in the Export button
import { AlertIcon, HeartIcon, LibraryIcon } from './Icons';

export const RiskPredictor: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<PredictionResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [entryMode, setEntryMode] = useState<'upload' | 'manual'>('upload');
  
  const [vitals, setVitals] = useState<PatientVitals>({
    age: 65, bnp: 450, lvef: 40, systolicBP: 130, diastolicBP: 85, heartRate: 72
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const handlePredict = async () => {
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      let prediction;
      if (entryMode === 'upload' && file) {
        prediction = await clinicalApi.predict(file);
      } else {
        // Simulate file creation from manual vitals
        const csvContent = `age,bnp,lvef,sbp,dbp,hr\n${vitals.age},${vitals.bnp},${vitals.lvef},${vitals.systolicBP},${vitals.diastolicBP},${vitals.heartRate}`;
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const virtualFile = new File([blob], 'manual_entry.csv', { type: 'text/csv' });
        prediction = await clinicalApi.predict(virtualFile);
      }
      setResult(prediction);
    } catch (err: any) {
      setError(err.message || 'Failed to process prediction.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (prob: number) => {
    if (prob < 0.2) return 'bg-emerald-500';
    if (prob < 0.5) return 'bg-amber-500';
    return 'bg-rose-500';
  };

  const getTrendText = (res: PredictionResponse) => {
    const diff = res.risk_30d - res.risk_1d;
    if (diff > 0.1) return { text: 'Increasing Risk', color: 'text-rose-500', icon: '↑' };
    if (diff < -0.1) return { text: 'Decreasing Risk', color: 'text-emerald-500', icon: '↓' };
    return { text: 'Stable Trend', color: 'text-slate-500', icon: '→' };
  };

  const RiskCard = ({ title, prob, label }: { title: string, prob: number, label: string }) => (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col items-center text-center">
      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{label}</span>
      <h4 className="text-lg font-bold text-slate-800 mb-4">{title}</h4>
      <div className="relative w-32 h-32 flex items-center justify-center">
        <svg className="w-full h-full transform -rotate-90">
          <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="10" fill="transparent" className="text-slate-100" />
          <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="10" fill="transparent" strokeDasharray={364.4} strokeDashoffset={364.4 * (1 - prob)} strokeLinecap="round" className={`${prob < 0.2 ? 'text-emerald-500' : prob < 0.5 ? 'text-amber-500' : 'text-rose-500'} transition-all duration-1000`} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-black text-slate-800">{(prob * 100).toFixed(0)}%</span>
        </div>
      </div>
      <div className={`mt-6 px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white ${getRiskColor(prob)}`}>
        {prob < 0.2 ? 'Low' : prob < 0.5 ? 'Moderate' : 'High'}
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto py-8 pb-32">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-slate-800">ML Risk Forecaster</h2>
        <div className="mt-4 flex justify-center p-1 bg-slate-200 rounded-xl w-fit mx-auto">
          <button 
            onClick={() => setEntryMode('upload')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${entryMode === 'upload' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
          >
            File Upload
          </button>
          <button 
            onClick={() => setEntryMode('manual')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${entryMode === 'manual' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
          >
            Manual Entry
          </button>
        </div>
      </div>

      {entryMode === 'upload' ? (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center hover:border-teal-500 transition-colors group">
          <input type="file" id="clinical-data-upload" className="hidden" onChange={handleFileChange} accept=".csv,.json" />
          <label htmlFor="clinical-data-upload" className="cursor-pointer flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-teal-50 group-hover:text-teal-600 transition-all mb-4">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            {file ? (
              <p className="font-bold text-slate-800">{file.name}</p>
            ) : (
              <p className="font-bold text-slate-800">Upload CSV or JSON dataset</p>
            )}
          </label>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Age</label>
              <input 
                type="number" 
                value={vitals.age} 
                onChange={(e) => setVitals({...vitals, age: +e.target.value})}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">BNP (pg/mL)</label>
              <input type="number" value={vitals.bnp} onChange={(e) => setVitals({...vitals, bnp: +e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-teal-500" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">LVEF (%)</label>
              <input type="number" value={vitals.lvef} onChange={(e) => setVitals({...vitals, lvef: +e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-teal-500" />
            </div>
          </div>
        </div>
      )}

      {(file || entryMode === 'manual') && (
        <button 
          onClick={handlePredict}
          disabled={isLoading}
          className="mt-8 bg-teal-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-teal-700 transition-all shadow-lg mx-auto flex items-center gap-2 disabled:bg-slate-300"
        >
          {isLoading ? 'Analysing...' : 'Generate Clinical Risk Profile'}
        </button>
      )}

      {error && <div className="mt-6 bg-rose-50 text-rose-700 p-4 rounded-2xl border border-rose-200 text-sm">{error}</div>}

      {result && (
        <div className="mt-12 space-y-8 animate-in fade-in slide-in-from-bottom-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <RiskCard title="1-Day" prob={result.risk_1d} label="Immediate" />
            <RiskCard title="7-Day" prob={result.risk_7d} label="Short Term" />
            <RiskCard title="30-Day" prob={result.risk_30d} label="Monthly" />
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold text-slate-800">Temporal Risk Trajectory</h3>
              <div className={`px-3 py-1 rounded-lg font-bold text-sm ${getTrendText(result).color} bg-slate-50 border border-slate-100`}>
                {getTrendText(result).icon} {getTrendText(result).text}
              </div>
            </div>
            
            <div className="h-48 relative pt-4">
              <div className="absolute inset-0 flex items-end justify-between px-10 text-[10px] text-slate-300 pointer-events-none border-b border-slate-100 pb-1">
                <span>Day 1</span><span>Day 7</span><span>Day 30</span>
              </div>
              <svg className="w-full h-full overflow-visible" preserveAspectRatio="none">
                 {(() => {
                    const y1 = 100 - (result.risk_1d * 100);
                    const y7 = 100 - (result.risk_7d * 100);
                    const y30 = 100 - (result.risk_30d * 100);
                    return <path d={`M 0,${y1} L 25%,${y7} L 100%,${y30}`} fill="none" stroke="#0d9488" strokeWidth="3" strokeLinecap="round" />;
                 })()}
              </svg>
            </div>
          </div>
          
          <button 
            onClick={() => window.print()}
            className="w-full bg-slate-100 text-slate-600 py-3 rounded-xl font-bold hover:bg-slate-200 transition-all flex items-center justify-center gap-2 border border-slate-200"
          >
            <LibraryIcon className="w-4 h-4" />
            Export Clinical Summary Report (PDF)
          </button>
        </div>
      )}
    </div>
  );
};
