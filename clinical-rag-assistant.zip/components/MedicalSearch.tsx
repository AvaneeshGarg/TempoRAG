
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ResearchItem } from '../types';
import { SearchIcon, LibraryIcon } from './Icons';

export const MedicalSearch: React.FC = () => {
  const [query, setQuery] = useState('Latest clinical trials for Heart Failure with preserved ejection fraction 2025');
  const [results, setResults] = useState<ResearchItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [answer, setAnswer] = useState('');

  const performSearch = async () => {
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: query,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const text = response.text || "No summary available.";
      setAnswer(text);

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const formattedResults = chunks
        .filter((chunk: any) => chunk.web)
        .map((chunk: any) => ({
          title: chunk.web.title || "Medical Source",
          url: chunk.web.uri,
          snippet: "Retrieved via Google Search grounding."
        }));

      setResults(formattedResults);
    } catch (error) {
      console.error("Search error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-800">Medical Research Pulse</h2>
        <p className="text-slate-500 mt-2">Grounded real-time search for the latest clinical breakthroughs and guidelines.</p>
      </div>

      <div className="flex gap-2 mb-8">
        <div className="flex-1 relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 pl-11 focus:ring-2 focus:ring-teal-500 outline-none shadow-sm"
            placeholder="Search clinical trials, guidelines, or drug updates..."
          />
          <SearchIcon className="absolute left-4 top-3.5 text-slate-400" />
        </div>
        <button
          onClick={performSearch}
          disabled={isLoading}
          className="bg-slate-900 text-white px-6 py-3 rounded-xl font-bold hover:bg-slate-800 transition-all disabled:bg-slate-300"
        >
          {isLoading ? 'Searching...' : 'Search'}
        </button>
      </div>

      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-40 bg-slate-100 animate-pulse rounded-2xl"></div>
          ))}
        </div>
      )}

      {!isLoading && answer && (
        <div className="mb-8 bg-teal-50 border border-teal-100 p-6 rounded-2xl">
          <h3 className="text-teal-900 font-bold mb-2 flex items-center gap-2">
            <LibraryIcon className="w-5 h-5" />
            Synthesis Summary
          </h3>
          <div className="text-slate-700 leading-relaxed text-sm italic">
            {answer}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {results.map((res, i) => (
          <a
            key={i}
            href={res.url}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white border border-slate-200 p-5 rounded-2xl hover:border-teal-500 hover:shadow-lg transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-teal-100 text-teal-700 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Verified Source</span>
              </div>
              <h4 className="font-bold text-slate-800 line-clamp-2 mb-2">{res.title}</h4>
              <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">{res.snippet}</p>
            </div>
            <div className="mt-4 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              <span>Grounding Tool</span>
              <span className="text-teal-600">View Article →</span>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};
